#!/bin/bash

echo creating test1 and test2 table in test database
mysql test < ./create_two_tables.sql
